import { createContext, useContext, useState, useEffect } from 'react';
import { questions as defaultQuestions } from '../data/questions';
import { letterContent as defaultLetter } from '../data/letter';

const ValentineContext = createContext();

export function ValentineProvider({ children }) {
  // Default State (The "Demo" content)
  const [data, setData] = useState({
    senderName: "Admirer",
    recipientName: "Valentine",
    questions: defaultQuestions,
    letter: defaultLetter,
    cardImage: null, // URL or base64
    cardMessage: "Happy Valentine's Day!",
  });

  // Simple "Load by ID" simulation for now
  // In the future, this calls Supabase
  const loadValentine = async (id) => {
    // 1. Try to load from "DB" (Simulating with LocalStorage for immediate demo)
    const savedData = localStorage.getItem(`valentine_${id}`);
    if (savedData) {
      setData(JSON.parse(savedData));
      return true;
    }
    return false;
  };

  const createValentine = async (newData) => {
    // 1. Generate unique ID
    const id = Date.now().toString(36) + Math.random().toString(36).substr(2);
    // 2. Save to "DB"
    localStorage.setItem(`valentine_${id}`, JSON.stringify(newData));
    return id;
  };

  const updateField = (field, value) => {
    setData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <ValentineContext.Provider value={{ data, updateField, loadValentine, createValentine }}>
      {children}
    </ValentineContext.Provider>
  );
}

export function useValentine() {
  return useContext(ValentineContext);
}
